import en from './languages/en'
import pt from './languages/pt'

export default {
    en,
    pt
}