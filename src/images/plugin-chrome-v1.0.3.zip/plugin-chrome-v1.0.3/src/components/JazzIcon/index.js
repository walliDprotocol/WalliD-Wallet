export { default } from "./JazzIcon.vue";
