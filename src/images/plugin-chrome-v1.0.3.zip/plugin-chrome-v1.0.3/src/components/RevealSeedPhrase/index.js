export { default } from "./RevealSeedPhrase.vue";
