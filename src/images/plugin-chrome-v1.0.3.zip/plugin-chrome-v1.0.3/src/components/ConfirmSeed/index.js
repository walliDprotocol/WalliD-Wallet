export { default } from "./ConfirmSeed.vue";
