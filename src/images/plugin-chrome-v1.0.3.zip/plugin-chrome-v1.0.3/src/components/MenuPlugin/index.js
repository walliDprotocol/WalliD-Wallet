export { default } from "./MenuPlugin.vue";
