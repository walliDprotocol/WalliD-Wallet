export { default } from "./RevealPrivateKey.vue";
