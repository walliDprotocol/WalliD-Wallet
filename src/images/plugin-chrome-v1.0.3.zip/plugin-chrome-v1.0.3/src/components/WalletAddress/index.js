export { default } from "./WalletAddress.vue";
