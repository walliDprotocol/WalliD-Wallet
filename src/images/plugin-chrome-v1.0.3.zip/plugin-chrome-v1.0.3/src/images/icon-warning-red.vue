<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="23"
    height="22"
    viewBox="0 0 23 22"
  >
    <g fill="none" fill-rule="evenodd">
      <g fill="#E95E5E" fill-rule="nonzero">
        <g>
          <path
            d="M22.637 17.036L13.856 1.398C13.37.536 12.469 0 11.5 0c-.969 0-1.871.536-2.356 1.398L.364 17.035c-.485.863-.485 1.935 0 2.797.483.863 1.386 1.399 2.355 1.399h17.562c.97 0 1.872-.536 2.356-1.398.484-.863.484-1.935 0-2.797zm-9.833-.292h-2.607v-2.067h2.607v2.067zm0-3.379h-2.607V6.833h2.607v6.532z"
            transform="translate(-39 -435) translate(39 435)"
          />
        </g>
      </g>
    </g>
  </svg>
</template>
