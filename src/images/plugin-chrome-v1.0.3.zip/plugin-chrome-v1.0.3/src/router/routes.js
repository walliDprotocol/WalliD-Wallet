export const DETAILS = "/details";
export const SITES = "/sites";
export const SETTINGS = "/settings";
export const ABOUT = "/about";
export const RESTORE = "/restore";
export const CREATE = "/create";
