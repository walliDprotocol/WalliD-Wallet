<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="22"
    height="22"
    viewBox="0 0 22 22"
  >
    <g fill="#373C43">
      <path
        d="M22 .234H6v16h16v-16zm-1.778 14.222H7.778V2.012h12.444v12.444z"
      />
      <path
        d="M4.036 7.717L4.036 6 0 6 0 22 16 22 16 17.993 14.283 17.993 14.283 20.283 1.717 20.283 1.717 7.717z"
      />
    </g>
  </svg>
</template>
