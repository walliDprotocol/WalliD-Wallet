<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="9"
    height="9"
    viewBox="0 0 9 9"
  >
    <g fill="none" fill-rule="evenodd">
      <g fill="#E95E5E" fill-rule="nonzero">
        <g>
          <path
            d="M3.325 4.5L0 1.175 1.175 0 4.5 3.325 7.825 0 9 1.175 5.675 4.5 9 7.825 7.825 9 4.5 5.675 1.175 9 0 7.825z"
            transform="translate(-8 -7) translate(8 7)"
          />
        </g>
      </g>
    </g>
  </svg>
</template>
