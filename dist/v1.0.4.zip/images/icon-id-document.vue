<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="30"
    height="30"
    viewBox="0 0 30 30"
  >
    <g fill="none" fill-rule="evenodd">
      <g>
        <g transform="translate(-20 -428) translate(20 428)">
          <circle cx="15.143" cy="15.143" r="13" fill="#DBEDEF" />
          <g fill="#009FB1" fill-rule="nonzero">
            <path
              d="M16.875 1.12v9.76H1.125V1.12h15.75zm0-1.12H1.125C.506 0 0 .505 0 1.12v9.76C0 11.495.507 12 1.125 12h15.75c.619 0 1.125-.504 1.125-1.12V1.12C18 .505 17.494 0 16.875 0z"
              transform="translate(6 9)"
            />
            <path
              d="M6 7c-2.206 0-4 1.346-4 3h8c0-1.654-1.795-3-4-3zM6 2c-1.103 0-2 .897-2 2s.897 2 2 2 2-.897 2-2-.897-2-2-2z"
              transform="translate(6 9)"
            />
            <path
              d="M6 7c-2.206 0-4 1.346-4 3h8c0-1.654-1.795-3-4-3zM6 2c-1.103 0-2 .897-2 2s.897 2 2 2 2-.897 2-2-.897-2-2-2zM11 3H16V4H11zM11 9H13V10H11zM14 9H16V10H14zM11 5H16V6H11z"
              transform="translate(6 9)"
            />
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
