<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="4"
    height="20"
    viewBox="0 0 4 20"
  >
    <g fill="#373C43" fill-rule="nonzero">
      <g
        transform="translate(-375 -527) translate(375 527) matrix(-1 0 0 1 4 0)"
      >
        <circle cx="2" cy="2" r="2" />
        <circle cx="2" cy="10" r="2" />
        <circle cx="2" cy="18" r="2" />
      </g>
    </g>
  </svg>
</template>
<style scoped>
</style>
