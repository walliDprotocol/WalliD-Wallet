<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="15"
    height="23"
    viewBox="0 0 15 23"
  >
    <g fill="none" fill-rule="evenodd">
      <g fill="#373C43" fill-rule="nonzero">
        <g>
          <g>
            <path
              d="M10.714 2.19V0H9.107C4.085 0 0 4.176 0 9.31c0 5.133 4.085 9.309 9.107 9.309h.536V23L15 17.524l-5.357-5.476v4.38h-.536c-3.84 0-6.964-3.193-6.964-7.118 0-3.926 3.124-7.12 6.964-7.12h1.607z"
            />
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
