<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="10"
    height="10"
    viewBox="0 0 12 12"
  >
    <g fill="none" fill-rule="evenodd">
      <g fill="#F79520" fill-rule="nonzero" stroke="#F79520" stroke-width=".5">
        <g>
          <g>
            <path
              d="M5 0C2.243 0 0 2.243 0 5s2.243 5 5 5 5-2.243 5-5-2.243-5-5-5zm0 9.236C2.665 9.236.764 7.336.764 5 .764 2.665 2.664.764 5 .764S9.236 2.664 9.236 5 7.336 9.236 5 9.236zm.382-7.699h-.764v3.621L6.479 7.02l.54-.54-1.637-1.638V1.537z"
              transform="translate(-71 -640) translate(65 635) translate(7 6)"
            />
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
