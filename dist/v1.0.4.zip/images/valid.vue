<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="11"
    height="8"
    viewBox="0 0 11 8"
  >
    <g fill="none" fill-rule="evenodd">
      <g fill="#00E284">
        <path
          d="M13.141 14.095L13.14 14.094 12.243 15 8 10.716 9.167 9.537 12.244 12.643 17.833 7 19 8.179z"
          transform="translate(-8 -7)"
        />
      </g>
    </g>
  </svg>
</template>
