<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="10"
    height="16"
    viewBox="0 0 10 16"
  >
    <g fill="none" fill-rule="evenodd">
      <g fill="#373C43" fill-rule="nonzero">
        <g>
          <g>
            <path
              d="M10 1.708L8.182 0 0 7.684 0.009 7.692 0 7.701 8.182 15.385 10 13.677 3.627 7.692z"
              transform="translate(-370 -435) matrix(-1 0 0 1 380 435)"
            />
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
