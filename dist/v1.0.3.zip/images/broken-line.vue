<template>
  <svg
    width="131"
    height="2"
    viewBox="0 0 131 2"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M0 1H134"
      stroke="#CDD1E4"
      strokeLinejoin="round"
      strokeDasharray="8 7"
    />
  </svg>
</template>
