<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="15"
    height="10"
    viewBox="0 0 15 10"
  >
    <g fill="none" fill-rule="evenodd">
      <g fill="#373C43" fill-rule="nonzero">
        <g>
          <g>
            <path
              d="M9 1.554L7.364 0 0 6.992 0.008 7 0 7.008 7.364 14 9 12.446 3.264 7z"
              transform="translate(-348 -260) translate(348 260) matrix(0 -1 -1 0 14.5 9.5)"
            />
          </g>
        </g>
      </g>
    </g>
  </svg>
</template>
