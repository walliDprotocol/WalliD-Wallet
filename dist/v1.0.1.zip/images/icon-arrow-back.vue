<template>
    <svg xmlns="http://www.w3.org/2000/svg" width="10" height="16" viewBox="0 0 10 16">
        <path fill="#373C43" d="M10 1.708L8.182 0 0 7.684 0.009 7.692 0 7.701 8.182 15.385 10 13.677 3.627 7.692z"/>
    </svg>
</template
