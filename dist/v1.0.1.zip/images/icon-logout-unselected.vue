<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="23"
    height="19"
    viewBox="0 0 23 19"
  >
    <g fill="none" fill-rule="evenodd">
      <g fill="#373C43" fill-rule="nonzero">
        <g>
          <path
            d="M8.609 1.9L8.609 0 -0.957 0 -0.957 19 8.609 19 8.609 17.1 0.957 17.1 0.957 1.9z"
            transform="translate(1)"
          />
          <path
            d="M13.669 5.425L16.825 8.55 4.783 8.55 4.783 10.45 16.825 10.45 13.669 13.575 15.027 14.925 20.479 9.5 15.027 4.075z"
            transform="translate(1)"
          />
        </g>
      </g>
    </g>
  </svg>
</template>
